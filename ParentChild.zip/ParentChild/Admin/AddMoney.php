
<?php
    session_start();
    if(!$_SESSION['Login']){

        header('location:AdminLogin.php');
    }
   // echo "welcome ". $_SESSION['un'];
?>
<html>
    <title>Home Page</title>
        <link href="../css/Style.css" rel="stylesheet">

<?php
    include 'header.php';
?>
<center><footer>
   This page is created by &copy;Sifa
</footer></center> 
    <style>
        div{
            background-color: blanchedalmond;
            margin: 130px;
        }
        input[type="submit"]{
            border-radius:20px;
            width:130px;
            height:40px;
            color:white;
            background-color: green;
            font-size: 20px;
        }
        input[type="reset"]{
            border-radius:20px;
            width:130px;
            height:40px;
            color:white;
            background-color: darkred;
            font-size: 20px;
        }
    </style>
    <body>
        <form method="post">
            <br>
           <center><div id="form1">
                <h1> Add Money</h1>
                <label>Date:</label><input type="text" name="date" value="<?php echo date('y/m/d');?>"/>&nbsp;&nbsp;
                <label>Money:</label><input type="Number" name="amount">&nbsp;&nbsp;
                <label>Description:</label><input type="text" name="desc">&nbsp;&nbsp;<br><br>
                <input type="submit" name="save" value="save"> 

            </div></center>
        </form>
    </body>
</html>

<?php
    if(isset($_POST['logout'])){

        $_SESSION['Login']=false;
        header('location:AdminLogin.php');
    }
?>
<?php
    if (isset($_POST['save'])){
        include 'connection.php';
        $adminemail=$_SESSION['un1'];
        $sql="insert into adminmoney values(DEFAULT,'".$adminemail."','".$_POST['date']."','".$_POST['amount']."','".$_POST['desc']."','Credited')";
        $sql1="UPDATE total SET total=total+ '".$_POST['amount']."' where AdminEmail='{$_SESSION['un1']}'";
         $sql2="insert into transactionhistory values(DEFAULT,'".$adminemail."','".$_POST['date']."','".$_POST['desc']."','".$_POST['desc']."','".$_POST['amount']."','Credited')";
        if($c->query($sql)===true && $c->query($sql1)===true  && $c->query($sql2)===true)
        {
            echo "Record inserted successfully";
            header('location:Home.php');
        }
        else{
            echo "<script>alert('Something went wrong');</script>.$c->error;";
            
        }
        $c->close();
    }
?>