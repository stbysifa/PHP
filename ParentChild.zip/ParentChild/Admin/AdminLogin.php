<?php

session_start(); 
?>
    <title>Admin Login</title>
    <style>
         div{
            background-color:aqua;
            margin: 130px;
        }
        label{
             font-size: 20px;  
        }
         input[type="submit"]{
            border-radius:20px;
            width:130px;
            height:40px;
            color:white;
            background-color: green;
            font-size: 20px;
        }
        input[type="reset"]{
            border-radius:20px;
            width:130px;
            height:40px;
            color:white;
            background-color: darkred;
            font-size: 20px;
        }
    </style>
    <body>
        <form method="post">
          <center><div id="name">
                <h2>Admin Login</h2>
                <label>Username:</label>&nbsp;<input type="text" required placeholder="Username" name="email"><br><br>
                <label>Password:</label>&nbsp;<input type="password" required placeholder="Password" name="password"><br><br>
                <input type="submit" value="Login" name="login">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="reset">
            </div></center>
        </form>
    </body>


<?php

    if(isset($_POST['login'])){

    include 'connection.php';

    $un=$_POST['email'];
    $pw=$_POST['password'];

    $sql="select * from adminlogin where AdminEmail='".$un."' AND AdminPW='".$pw."'";
    $r=$c->query($sql);

    if($r->num_rows>0){
        while($row=$r->fetch_assoc()){
             $_SESSION['un']=$row['AdminName'];
             $_SESSION['un1']=$row['AdminEmail'];
             $_SESSION['Login']=true;
             header("location:Home.php");
        }
        
    }
    else{
        echo "<script>alert('Invalid details');</script>";
    }
}


?>