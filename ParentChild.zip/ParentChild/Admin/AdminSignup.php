<html>
    <title>Admin new account signup</title>
    <style>
        h1{
            font-size: 60px;
            border:2px solid;
            margin:50px;
        }
        div{
            text-align:center;
            border:5px solid;
            margin:50px;
            background-color:bisque;
        }
        label{
             font-size: 20px;  
        }
        input[type="text"],[type="email"],[type="date"],[type="password"]{
            width:200px;
            height:30px;
            border:2px solid;
            border-radius:5px;
        }
        input[type="submit"]{
            border-radius:20px;
            width:130px;
            height:40px;
            color:white;
            background-color: green;
            font-size: 20px;
        }
        input[type="reset"]{
            border-radius:20px;
            width:130px;
            height:40px;
            color:white;
            background-color: darkred;
            font-size: 20px;
        }
    </style>
    
    <body>
        <form method="post">
            <div>
            <h1>Admin New Account Signup</h1>
            <label>Name:</label>&nbsp;&nbsp;<input type="text" placeholder="Your name" required name="AdminName"><br><br>
            <label>Email id:</label>&nbsp;<input type="email" placeholder="Emailid" name="AEmail" required><br><br>
            <label>Date of birth:</label>&nbsp;<input type="date" required name="ADOB"><br><br>
            <label>Username:</label>&nbsp;<input type="text" name="AUsername" placeholder="new user name" required><br><br>
            <label>Password:</label>&nbsp;<input type="password" name="APassword" placeholder="new password" required><br><br>
            <label>Confirm Password:</label>&nbsp;<input type="password" placeholder="retype new password" name="RAPassword"required><br><br>
            <input type="submit" name="signup">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="reset"><br><br>
            </div>
        </form>
    </body>
</html>

<?php
    if (isset($_POST['signup'])){
        include 'connection.php';
        $sql="insert into adminlogin values('".$_POST['AdminName']."','".$_POST['AEmail']."','".$_POST['ADOB']."','".$_POST['AUsername']."','".$_POST['APassword']."')";
        

        if($c->query($sql)===true)
        {
            $sql1="insert into total values(0,'".$_POST['AEmail']."')";
            if($c->query($sql1)===true){

            echo "<script>alert('Record Inserted Successfully');</script>";
            header('location:Adminlogin.php');
            }
        }
        else{
            echo "<script>alert('Something went wrong');</script>.$c->error;";
            
        }
        $c->close();
    }
?>