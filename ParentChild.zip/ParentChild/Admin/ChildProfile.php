<?php
    session_start();
    if(!$_SESSION['Login']){
        header('location:ChildLogin.php');
    }
?>
<html>
    <title>Display</title>
    <title>Add Child Expense</title>
         <link href="../css/Style.css" rel="stylesheet">
<?php
    include 'header.php';
?>
<center><footer>
   This page is created by &copy;Sifa
</footer></center> 
    <style>
        input[type='button']{
            width:180px;
            height:25px;
            border-radius: 20px;
        }
        div{
            margin: 20px;
            padding-top: 20px;   
        }
    </style>
    <script>
        function printPage() {
          window.print();
        }
    </script>
    <body>
        <?php
            include 'connection.php';
            $sql="select * from childlogin";
            $row=$c->query($sql);
         ?>
        <form>
         <div id="table"><center><h1>Children Profile</h1><table border=3 cellpadding=5  cellspacing=5>
            <tr>
                <th>Name</th>
                <th>Date Of Birth</th>
                <th>Child Username</th>
                <th>Password</th>
                <th>Balance</th>
            </tr>
             <?php 
                if($row->num_rows>0){
                    while($r=$row->fetch_assoc()){
            ?>
            <tr>
            
                 <td><input type="text" value="<?php echo $r['cname'] ?>"></td>
                <td><input type="text" value="<?php echo $r['cdob']?>"></td>
                <td><input type="text" value="<?php echo $r['cusername']?>"></td>
                <td><input type="text" value="<?php echo $r['cpassword']?>"></td> 
                <td><input type="text" value="<?php echo $r['Balance']?>"></td>
                <td><a href="Profile.php?id=<?php echo $r['cusername']?>">View</a></td>
                 <td><a href="ChildExpense.php?id=<?php echo $r['cusername']?>">Expense</a></td>
            </tr>
               <?php
                    }
                }   

            ?>
        </table>
             <br>
             <input type="button" value="Print this page" onclick="printPage()" />
        </center> 
        </div>
      </form>
        
    </body>
</html>
<?php

    if(isset($_POST['logout'])){

        $_SESSION['Login']=false;
        header('location:ChildHome.php');
    }
?>