<?php
    session_start();
    if(!$_SESSION['Login']){

        header('location:AdminLogin.php');
    }
     echo "welcome ". $_SESSION['un'];
?>
<html>
    <title>Expense Admin</title>
    <link href="../css/Style.css" rel="stylesheet">

<?php
    include 'header.php';
?>
<center><footer>
   This page is created by &copy;Sifa
</footer></center> 

    <style>
         div{
            background-color:azure;
        }
        label{
             font-size: 20px;  
        }
         input[type="submit"]{
            border-radius:20px;
            width:130px;
            height:40px;
            color:white;
            background-color: green;
            font-size: 20px;
        }
        input[type="reset"]{
            border-radius:20px;
            width:130px;
            height:40px;
            color:white;
            background-color: darkred;
            font-size: 20px;
        }       

    </style>
    <body>
        <form method="post">
          <center><div id="expense"><br>
                <h2>Expenses</h2><br>
                <label>Date:</label>&nbsp;<input type="date" name="date"><br><br>
                <label>Expense:</label>&nbsp;<input type="number" placeholder="expense" required placeholder="expense" name="expense"><br><br>
                <label>Description:</label>&nbsp;<textarea required name="description"></textarea><br><br>
              <label>Type:</label>&nbsp;
               <select id="names" name="type">
                   <option >Select</option>
                    <option>Bus</option>
                    <option>Canteen</option>
                    <option>Groceries</option>
                    <option>Books</option>
                </select><br><br>
              <label>To whom:</label>
              <input type="text" list="names1" name="towhom" required>
                <?php
                        include 'connection.php';
                        $sql="select * from childlogin";
                        $row=$c->query($sql);

                        $c->close();
                    
                ?>

                    <datalist id="names1">
                         <?php 

                    if($row->num_rows>0){
                        while($r=$row->fetch_assoc())
                        {


                 ?>
                    <option><?php echo $r['cname']?></option>
                    <?php
                }
            }
            ?>
                </datalist>

                <br><br>
              <label>File:</label><input type="file" name="file"><br><br>
              <input type="submit" name="save" value="save">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="reset">
              <br><br>
            </div>
            </center>
        </form>
    </body>
</html>

<?php
    if(isset($_POST['logout'])){

        $_SESSION['Login']=false;
        header('location:AdminLogin.php');
    }
?>
<?php
    if (isset($_POST['save'])){
        include 'connection.php';
        $adminemail=$_SESSION['un1'];

        $sql2="select * from total where AdminEmail='".$_SESSION['un1']."'";
        $row=$c->query($sql2);
        while($r=$row->fetch_assoc()){
            $GLOBAL['total']=$r['total'];
        }
        $sql="insert into adminexpense values(DEFAULT,'".$adminemail."','".$_POST['date']."','".$_POST['expense']."','".$_POST['description']."','".$_POST['type']."','".$_POST['towhom']."','".$_POST['file']."')";

        $sql4="insert into childtransaction values('".$adminemail."','".$_POST['towhom']."','".$_POST['date']."','".$_POST['expense']."','Credited',DEFAULT)";

        $sql5="insert into transactionhistory values(DEFAULT,'".$adminemail."','".$_POST['date']."','".$_POST['description']."','".$_POST['towhom']."','".$_POST['expense']."','Debited')";

         $sql1="UPDATE childlogin SET balance=balance+ ".$_POST['expense']." where cusername='".$_POST['towhom']."'";

         $sql3="UPDATE total SET total=total- ".$_POST['expense']." where AdminEmail='".$_SESSION['un1']."'";
         if($GLOBAL['total']>=$_POST['expense']){
            if($c->query($sql)===true && $c->query($sql1)===true && $c->query($sql4)===true && $c->query($sql5)===true)
            {
                $c->query($sql3);
                

                echo "Record inserted successfully";
                //header('location:ChildSignup.php');
            }
            else{
                echo "<script>alert('Something went wrong');</script>.$c->error;";
                
            }
        }
        else{
                echo "<script>alert('Insufficient Fund ');</script>.$c->error;";
                
            }
        $c->close();
    }
?>