
<?php
    session_start();
    if(!$_SESSION['Login']){

        header('location:AdminLogin.php');
    }
    echo "welcome ". $_SESSION['un'];
?>
<html>
    <title>Home Page</title>
        <link href="../css/Style.css" rel="stylesheet">

<?php
    include 'header.php';
?>
<center><footer>
   This page is created by &copy;Sifa
</footer></center> 
    <style>
        div{
            background-color: blanchedalmond;
            margin: 130px;
        }
        input[type="submit"]{
            border-radius:20px;
            width:130px;
            height:40px;
            color:white;
            background-color: green;
            font-size: 20px;
        }
        input[type="reset"]{
            border-radius:20px;
            width:130px;
            height:40px;
            color:white;
            background-color: darkred;
            font-size: 20px;
        }
    </style>
    <body>
        <form>
            <br>
           <center><div id="form1">
                <h1> Total Amount Available</h1>
                 <label>Date:</label><input type="text" name="date" value="<?php echo date('m/d/y');?>"/>&nbsp;&nbsp;
                <label>Balance:</label>
                  <?php
                    include 'connection.php';
                    $sql="SELECT total FROM total WHERE AdminEmail ='{$_SESSION['un1']}'";

                    $result=$c->query($sql);
                    if ($result->num_rows > 0) {
                      // output data of each row
                      while($row = $result->fetch_assoc()) {                           
                ?>
                <input type="text" name="balance" value='<?php echo $row['total']; ?>'>

                <?php
                    }
                }
                ?>
            </div></center>
        </form>
    </body>
</html>

<?php
    if(isset($_POST['logout'])){

        $_SESSION['Login']=false;
        header('location:AdminLogin.php');
    }
?>