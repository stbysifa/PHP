<?php
	session_start();
	$_SESSION['Login']=false;
	header('location:AdminLogin.php');
?>