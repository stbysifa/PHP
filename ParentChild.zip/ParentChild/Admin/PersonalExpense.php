<?php
    session_start();
    if(!$_SESSION['Login']){

        header('location:AdminLogin.php');
    }
     echo "welcome ". $_SESSION['un'];
?>
<html>
    <title>Expense Admin</title>
    <link href="../css/Style.css" rel="stylesheet">

<?php
    include 'header.php';
?>
<center><footer>
   This page is created by &copy;Sifa
</footer></center> 

    <style>
         div{
            background-color:azure;
        }
        label{
             font-size: 20px;  
        }
         input[type="submit"]{
            border-radius:20px;
            width:130px;
            height:40px;
            color:white;
            background-color: green;
            font-size: 20px;
        }
        input[type="reset"]{
            border-radius:20px;
            width:130px;
            height:40px;
            color:white;
            background-color: darkred;
            font-size: 20px;
        }       

    </style>
    <body>
        <form method="post">
          <center><div id="expense"><br>
                <h2>Personal Expenses</h2><br>
                <label>Date:</label>&nbsp;<input type="date" name="date"><br><br>
                <label>Expense:</label>&nbsp;<input type="number" placeholder="expense" required placeholder="expense" name="expense"><br><br>
              <label>Type:</label>&nbsp;
               <select id="names" name="type">
                   <option >Select</option>
                    <option>Bus</option>
                    <option>Canteen</option>
                    <option>Groceries</option>
                    <option>Books</option>
                    <option>Other</option>
                </select><br><br>
              <label>Description:</label>&nbsp;<textarea required name="description"></textarea>
                <br><br>
              <label>File:</label><input type="file" name="file"><br><br>
              <input type="submit" name="save" value="save">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="reset">
              <br><br>
            </div>
            </center>
        </form>
    </body>
</html>

<?php
    if(isset($_POST['logout'])){

        $_SESSION['Login']=false;
        header('location:AdminLogin.php');
    }
?>
<?php
    if (isset($_POST['save'])){
        include 'connection.php';
        $adminemail=$_SESSION['un1'];
        $sql="insert into aepersonal values(DEFAULT,'".$_POST['date']."','".$_POST['expense']."','".$_POST['type']."','".$_POST['description']."','".$_POST['file']."','".$adminemail."','Debited')";
        $sql2="insert into transactionhistory values(DEFAULT,'".$adminemail."','".$_POST['date']."','".$_POST['description']."','".$_POST['description']."','".$_POST['expense']."','Debited')";
        $sql1="UPDATE total SET total=total- ".$_POST['expense']." where AdminEmail='".$_SESSION['un1']."'";
        if($c->query($sql)===true && $c->query($sql1) && $c->query($sql2))
        {
            echo "Record inserted successfully";
            //header('location:ChildSignup.php');
        }
        else{
            echo "<script>alert('Something went wrong');</script>.$c->error;"; 
        }
        $c->close();
    }
?>