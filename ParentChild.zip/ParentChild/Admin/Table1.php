<?php
  session_start();
  if(!$_SESSION['Login']){

    header('location:AdminLogin.php');
  }
//  echo 'welcome';
?>
<html>
    <title>Table 2</title>
        <link href="../css/Style.css" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

<?php
    include 'header.php';
?>
<center><footer>
   This page is created by &copy;Sifa
</footer></center> 

    <style>
        input[type='button']{
            width:180px;
            height:25px;
            border-radius: 20px;
        }
        div{
        background-color:aquamarine;
        text-align: center;
    }
    </style>
    <script>
function printPage() {
  window.print();
}
</script>
    <body>
        <?php
            include 'connection.php';
            $sql="select * from adminexpense";
            $row=$c->query($sql);
         ?>
        <form>
         <div id="table"><center><h1>Table 2</h1><table class="table-dark" border=3 cellpadding=5  cellspacing=5 >
            <tr>
                <th>Date</th>
                <th>Expense</th>
                <th>Description</th>
                <th>Type</th>
                <th>To whom</th>
                <th>Download</th>
            </tr>

            <?php 

                if($row->num_rows>0){
                    while($r=$row->fetch_assoc())
                    {


            ?>
            <tr>
                <td><input type="date" value="<?php echo $r['date']?>"></td>
                <td><input type="number" value="<?php echo $r['expense']?>"></td>
                <td><textarea ><?php echo $r["description"]?></textarea></td>
                <td><input type="text" value="<?php echo $r['type']?>"></td>
                <td><input type="text" list required value="<?php echo $r['to_whom']?>">
                <datalist id="xyz">
                    <option>Sifa</option>
                    <option>Namita</option>
                    <option>Rey</option>
                    <option>Iron man</option>
                    <option>Joy</option>
                    <option>Rao</option>
                </datalist><br><br></td>
                <td><center><input class="btn btn-success" type="button" value="download"></center></td>
            </tr>
            <?php
                    }

                }
            ?>
        </table>
             <br>
             <br>
             <input type="button" value="Print this page" onclick="printPage()"/>
        </center> 
        </div>
      </form>
    </body>
</html>

<?php
    if(isset($_POST['logout'])){

        $_SESSION['Login']=false;
        header('location:AdminLogin.php');
    }
?>