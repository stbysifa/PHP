<?php
  session_start();
  if(!$_SESSION['Login']){

    header('location:AdminLogin.php');
  }
//  echo 'welcome';
?>
<html>
    <title>Transactions</title>
        <link href="../css/Style.css" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

<?php
    include 'header.php';
?>
<center><footer>
   This page is created by &copy;Sifa
</footer></center> 

    <style>
        input[type='button']{
            width:180px;
            height:25px;
            border-radius: 20px;
        }
        div{
        background-color:aquamarine;
        text-align: center;
    }
    </style>
    <script>
function printPage() {
  window.print();
}
</script>
    <body>
        <?php
            include 'connection.php';
            $sql="select * from transactionhistory where AdminEMail ='{$_SESSION['un1']}'";
            $row=$c->query($sql);
         ?>
        <form>
         <div id="table"><center><br><br><h3>Transaction History</h3><table class="table-dark" border=3 cellpadding=5  cellspacing=5 >
            <tr>
                <th>Date</th>
                <th>Description</th>
                <th>To whom/from Whom</th>
                <th>Amount</th>
                <th>Debited/Credited</th>            
            </tr>

            <?php 
                if($row->num_rows>0){
                    while($r=$row->fetch_assoc())
                     {$v=$r['Debt'];
            ?>
            <tr>
                 <?php
                    if($v=='Credited'){
                     ?>
                <td><input type="date" value="<?php echo $r['date1']?>"style="color:green;"></td>
                <td><textarea style="color:green;"><?php echo $r["description"]?></textarea></td>
                <td><input type="text" value="<?php echo $r['toWhom_fromWhom']?>"style="color:green;"></td>
                 <td><input type="number" value="<?php echo $r['amount']?>"style="color:green;"></td>
                <td><input type="text" value="<?php echo $r['Debt']?>"style="color:green;"></td>
            <?php
                }
             else{
                 ?>
                 <td><input type="date" value="<?php echo $r['date1']?>"style="color:red;"></td>
                <td><textarea style="color:red;"><?php echo $r["description"]?></textarea></td>
                <td><input type="text" value="<?php echo $r['toWhom_fromWhom']?>"style="color:red;"></td>
                 <td><input type="number" value="<?php echo $r['amount']?>"style="color:red;"></td>
                <td><input type="text" value="<?php echo $r['Debt']?>"style="color:red;"></td>
                <?php
                  }
            ?>
            </tr>
               <?php
                    }

                }
            ?>
        </table>
             <br>
             <br>
             <input type="button" value="Print this page" onclick="printPage()"/>
        </center> 
        </div>
      </form>
    </body>
</html>

<?php
    if(isset($_POST['logout'])){

        $_SESSION['Login']=false;
        header('location:AdminLogin.php');
    }
?>