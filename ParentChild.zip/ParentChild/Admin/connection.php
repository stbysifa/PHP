<?php
	$s="localhost";
	        $u="root";
	        $p="";
	        $d="expense";
	        $c=new mysqli($s,$u,$p,$d);
	        if($c->connect_error)
	        {
	            echo "error";
	        }
 ?>
