<ul>
    <li><a href="Home.php">Home</a></li>
    <li><a href="Expense.php">Give money to</a></li>
    <li><a href="PersonalExpense.php">Personal Expense</a></li>
     <li><a href="Table1.php">Display</a></li>
     <li><a href="AddMoney.php">Add Money</a></li>
     <li><a href="Transaction.php">Transactions</a></li>
     <li><a href="ChildSignup.php">Child Signup</a></li>
     <li><a href="ChildProfile.php">Child Profile</a></li>
   <li style="float: right;"><a href="Logout.php" onclick='alert("You will be logged out !");'>Logout</a></li>
</ul>