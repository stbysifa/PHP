
<?php
    session_start();
    if(!$_SESSION['Login']){

        header('location:AdminLogin.php');
    }
    //echo 'welcome';
?>
<html>
    <title>Admin Main</title>
    <style>
        label{
             font-size: 20px;  
        }
         input[type="submit"]{
            border-radius:20px;
            width:130px;
            height:40px;
            color:white;
            background-color: green;
            font-size: 20px;
        }
    </style>
    <body>
        <form action="AdminLogin.php">
          <center><div id="name">
              <h2>Login as Admin</h2>
                <input type="submit">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <br><br><br><br><br>
            </div>
            </center>
        </form>
         <form action="AdminSignup.php">
          <center><div id="name">
              <h2>New admin user!</h2>
                <input type="submit">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <br><br><br><br><br>
            </div>
            </center>
        </form>
        </body>
        </html>

<?php
    if(isset($_POST['logout'])){

        $_SESSION['Login']=false;
        header('location:AdminLogin.php');
    }
?>