<link href="about.css" rel="stylesheet">
<link href="Style.css" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<ul>
    <li><a href="IndexChild.php">Main Page</a></li>
    <li><a href="Aboutus.php">About us</a></li>
    <li><a href="Contactus.php">Contact us</a></li>   
<div class="panel-footer"><footer>This page is created by &copy; Sifa </footer></div> 
<div id="about">
    <br>
    <div class="container">
  <div class="jumbotron">
    <center><h1>About us </h1></center>

    <p>This website is used to control daily expenses of a common family.</p>
    <p>We have number of options like new loign,Daly balance checker,Secured admin password etc.</p><br>
        </div>
    </div>
<table>
    <tr>
        <td>
            <img src="1_MGv5b9bNEIRcYPVxQ50m0Q.jpeg" width=200 height=200  class="img-rounded">
        </td>
        <td></td>
        <td><img src="39580866-office-wallpapers.jpg" width=200 height=200 class="img-circle"></td>
    <tr>
</table>
    
</div>