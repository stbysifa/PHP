<?php
    session_start();
    if(!$_SESSION['Login']){

        header('location:ChildLogin.php');
    }
     echo "welcome ". $_SESSION['un'];
?>
<html>
    <title>Add Child Expense</title>
         <link href="../css/Style.css" rel="stylesheet">
<ul>
  <?php
    include 'header.php';
  ?>
    <!-- <li><a href="ChildHome.php">Home</a></li>
    <li><a href="ChildDisplay.php">Display</a></li>
    <li style="float: right;"><a onclick="return confirm('Are you sure to logout')" href="Logout.php">Logout</a></li> -->
</ul>

<center><footer>
   This page is created by &copy;Sifa
</footer></center> 

    <style>
         div{
            background-color:burlywood;
            margin: 130px;
             border: solid 15px;
        }
        label{
             font-size: 20px;  
        }
         input[type="submit"]{
            border-radius:20px;
            width:130px;
            height:40px;
            color:white;
            background-color: green;
            font-size: 20px;
        }
        input[type="reset"]{
            border-radius:20px;
            width:130px;
            height:40px;
            color:white;
            background-color: darkred;
            font-size: 20px;
        }    

    </style>
    <body>
        <br>
        <form  method="post">
          <center><div id="expense">
                <h2>Add child expense</h2><br>
                <label>Date:</label>&nbsp;<input type="date" name="date"><br><br>
                <label>Expense:</label>&nbsp;<input type="number" name="expense" placeholder="expense" required placeholder="expense"><br><br>
                <label>Description:</label>&nbsp;<textarea required name="description"></textarea><br><br>
              <label>Type:</label>&nbsp;
               <select id="names" name="type">
                   <option >Select</option>
                    <option>Bus</option>
                    <option>Canteen</option>
                    <option>Groceries</option>
                    <option>Books</option>
                   <option>Stationary</option>
                   <option>Fees</option>
                </select><br><br>
              <label>File:</label><input type="file" name="file"><br><br>
              <input type="submit" name="save" value="save">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="reset">
              <br><br>
            </div>
            </center>
        </form>
    </body>
</html>
<?php
    if(isset($_POST['logout'])){

        $_SESSION['Login']=false;
        header('location:ChildHome.php');
    }
?>
<?php
    if (isset($_POST['save'])){
        include 'connection.php';
        $cusername=$_SESSION['un1'];

        $sql2="select * from childlogin where cusername='".$_SESSION['un1']."'";
        $row=$c->query($sql2);
        while($r=$row->fetch_assoc())
        {
            $GLOBAL['Balance']=$r['Balance'];
        }
        $sql="insert into childexpense(cusername,expense,description,type,file,date) values('".$cusername."','".$_POST['expense']."','".$_POST['description']."','".$_POST['type']."','".$_POST['file']."','".$_POST['date']."')";

        $sql3="UPDATE childlogin SET balance=balance- ".$_POST['expense']." where cusername='".$_SESSION['un1']."'";
         $sql4="insert into childtransaction values('NONE','".$cusername."','".$_POST['date']."','".$_POST['expense']."','Debited',DEFAULT)";

         if($GLOBAL['Balance']>=$_POST['expense'])
         {
            if($c->query($sql)===true && $c->query($sql3)===true && $c->query($sql4)===true)
              {
                  echo "Record inserted successfully";
                  //header('location:ChildSignup.php');
              }
           else{
                  echo "<script>alert('Something went wrong');</script>.$c->error;";
                  
              }
        }
        else{
                echo "<script>alert('Insufficient Fund ');</script>.$c->error;";

        }
        $c->close();
    }
?>