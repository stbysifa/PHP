<?php

session_start(); 
?>
<html>
    <title>Child Login</title>
        <link href="../css/Style.css" rel="stylesheet">
        <script src="../css/Js.js"></script>
<ul>
    <li><a href="Aboutus.php">About us</a></li>
    <li><a href="Contactus.php">Contact us</a></li>
</ul>
<center><footer>
   This page is created by &copy;Sifa
</footer></center> 

    <style>
         div{
            background-color:aquamarine;
            margin: 130px;
        }
        label{
             font-size: 20px;  
        }
         input[type="submit"]{
            border-radius:20px;
            width:130px;
            height:40px;
            color:white;
            background-color: green;
            font-size: 20px;
        }
        input[type="reset"]{
            border-radius:20px;
            width:130px;
            height:40px;
            color:white;
            background-color: darkred;
            font-size: 20px;
        }
    </style>
    <body>
        <form method="post">
            <br>
          <center><div id="name">
                <h2>Child Login</h2>
                <label>Username:</label>&nbsp;<input id="uname" type="text" required placeholder="Username" name="uname"><br><br>
                <label>Password:</label>&nbsp;<input id="pass" type="password" required placeholder="Password" name="password"><br><br>
                <input type="submit" name="login" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="reset">
            </div></center>
        </form>
    </body>
</html>

<?php

    if(isset($_POST['login'])){

    include 'connection.php';

    $un=$_POST['uname'];
    $pw=$_POST['password'];

    $sql="select * from childlogin where cusername='".$un."' AND cpassword='".$pw."'";
    $r=$c->query($sql);

    if($r->num_rows>0){
        while($row=$r->fetch_assoc()){
             $_SESSION['un']=$row['cname'];
             $_SESSION['un1']=$row['cusername'];
             $_SESSION['Login']=true;
             header("location:ChildHome.php");
        }
        
    }
    else{
        echo "<script>alert('Invalid details');</script>";
    }
}


?>