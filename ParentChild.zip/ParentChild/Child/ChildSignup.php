<html>
    <title>Admin new account for child</title>
    <link href="../css/Style.css" rel="stylesheet">
<ul>
    <li><a href="Home.php">Home</a></li>
    <li><a href="Table1.php">Display</a></li>
    <li><a href="Expense.php">Expense</a></li>
    <li style="float: right;"><a href="../Admin/AdminLogin.php">Logout</a></li>
</ul>
<center><footer>
   This page is created by &copy;Sifa
</footer></center> 

    <style>
        h1{
            font-size: 60px;
            border-radius:20px;
        }
        div{
            text-align:center;
            background-color:darkseagreen;
        }
        label{
             font-size: 20px;  
        }
        input[type="text"],[type="date"],[type="password"]{
            width:200px;
            height:30px;
            border:2px solid;
            border-radius:5px;
        }
        input[type="submit"]{
            border-radius:20px;
            width:130px;
            height:40px;
            color:white;
            background-color: green;
            font-size: 20px;
        }
        input[type="reset"]{
            border-radius:20px;
            width:130px;
            height:40px;
            color:white;
            background-color: darkred;
            font-size: 20px;
        }
    </style>
    
    <body>
        <form method="post">
            <div>
                <h1>Admin New Account For child</h1>
                <label>Name:</label>&nbsp;&nbsp;<input type="text" placeholder="Your Name" required name="Cname"><br><br>
                <label>Date of birth:</label>&nbsp;<input type="date" name="cdate"><br><br>
                <label>Username:</label>&nbsp;<input type="text" placeholder="New Username" name="cuname" required><br><br>
                <label>Password:</label>&nbsp;<input type="password" name="cpassword"placeholder="Password" required><br><br>
                <input type="submit" name="signup">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="reset"><br><br>
            </div>
        </form>
    </body>
</html>

<?php
    if (isset($_POST['signup'])){
        include 'connection.php';
        $sql="insert into childlogin values('".$_POST['Cname']."','".$_POST['cdate']."','".$_POST['cuname']."','".$_POST['cpassword']."')";

        if($c->query($sql)===true)
        {
            echo "<script>alert('Record Inserted Successfully');</script>";
            header('location:ChildSignup.php');
        }
        else{
            echo "<script>alert('Something went wrong');</script>.$c->error;";
            
        }
        $c->close();
    }
?>