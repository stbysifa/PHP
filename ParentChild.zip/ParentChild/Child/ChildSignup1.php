<html>
    <title>Admin new account for child</title>
        <link href="../css/Style.css" rel="stylesheet">
<ul>
    <li><a href="Aboutus.php">About us</a></li>
    <li><a href="Contactus.php">Contact us</a></li>
<center><footer>
   This page is created by &copy;Sifa
</footer></center> 

    <style>
        h1{
            font-size: 60px;
            border-radius:20px;
        }
        div{
            text-align:center;
            background-color:darkseagreen;
        }
        label{
             font-size: 20px;  
        }
        input[type="text"],[type="date"],[type="password"]{
            width:200px;
            height:30px;
            border:2px solid;
            border-radius:5px;
        }
        input[type="submit"]{
            border-radius:20px;
            width:130px;
            height:40px;
            color:white;
            background-color: green;
            font-size: 20px;
        }
        input[type="reset"]{
            border-radius:20px;
            width:130px;
            height:40px;
            color:white;
            background-color: darkred;
            font-size: 20px;
        }
    </style>
    
    <body>
        <form>
            <br>
            <div>
                <h1>Admin New Account For child</h1>
                <label>Name:</label>&nbsp;&nbsp;<input type="text" placeholder="Your Name" required><br><br>
                <label>Date of birth:</label>&nbsp;<input type="date"><br><br>
                <label>Username:</label>&nbsp;<input type="text" placeholder="New Username" required><br><br>
                <label>Password:</label>&nbsp;<input type="password" placeholder="Password" required><br><br>
                <input type="submit">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="reset"><br><br>
            </div>
        </form>
    </body>
</html>