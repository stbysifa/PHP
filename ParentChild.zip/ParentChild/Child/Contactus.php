
    <link href="../css/Style.css" rel="stylesheet">
<ul>
    <li><a href="IndexChild.php">Main Page</a></li>
    <li><a href="Aboutus.php">About us</a></li>
    <li><a href="Contactus.php">Contact us</a></li>
<center><footer>
   This page is created by &copy;Sifa
</footer></center> 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<table  class="table">
    <thead>
        <th>Contact us</th>
    </thead>
    <tbody>
        <tr class="success">
            <td>
                    Emailid
            </td>
            <td>sifatandel4nov@gmail.com
            </td>
        </tr>
          <tr class="info">
            <td>
                    Contact No
            </td>
            <td>9767555067
            </td>
        </tr>
        <tr class="danger">
            <td>
                    Facebook
            </td>
            <td>sifatandel/facebook.in
            </td>
        </tr>
    </tbody>
</table>