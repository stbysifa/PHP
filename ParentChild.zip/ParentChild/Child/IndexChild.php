<html>
    <title>Child </title>
    <link href="../css/Style.css" rel="stylesheet">
<ul>
    <li><a href="Aboutus.html">About us</a></li>
    <li><a href="Contactus.html">Contact us</a></li>
<center><footer>
   This page is created by &copy;Sifa
</footer></center> 

    <style>
        label{
             font-size: 20px;  
        }
         input[type="submit"]{
            border-radius:20px;
            width:130px;
            height:40px;
            color:white;
            background-color: green;
            font-size: 20px;
        }
    </style>
    <body>
        <form action="ChildLogin.php">
            <br>
          <center><div id="name">
              <h2>Login as Child</h2>
                <input type="submit">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <br><br><br><br><br>
            </div>
            </center>
        </form>
        <form action="ChildSignup1.php">
          <center><div id="name">
              <h2>New child user!</h2>
                <input type="submit">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <br><br><br><br><br>
            </div>
          </center>
        </form>
    </body>
</html>