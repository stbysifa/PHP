<?php
    session_start();
    if(!$_SESSION['Login']){
        header('location:ChildLogin.php');
    }
?>
<html>
    <title>Display</title>
    <title>Add Child Expense</title>
         <link href="../css/Style.css" rel="stylesheet">
<?php
    include 'header.php';
?>
<center><footer>
   This page is created by &copy;Sifa
</footer></center> 
    <style>
        input[type='button']{
            width:180px;
            height:25px;
            border-radius: 20px;
        }
        div{
            margin: 20px;
            padding-top: 20px;   
        }
    </style>
    <script>
        function printPage() {
          window.print();
        }
    </script>
    <body>
        <?php
            include 'connection.php';
            $sql="select * from childtransaction where cusername ='{$_SESSION['un1']}'";
            $row=$c->query($sql);
         ?>
        <form method="post">
         <div id="table"><center><h1>Transactions</h1><table border=3 cellpadding=5  cellspacing=5>
            <tr>
                <th>Date</th>
                <th>Expense</th>
                <th>Given By/Givento</th>
                <th>Debt/Credit</th>
            </tr>
             <?php 
                if($row->num_rows>0){
                    while($r=$row->fetch_assoc())
                    {$v=$r['Debit/Credit'];
            ?>
            <tr>
                <?php
                    if($v=='Credited'){
                     ?>
                <td><input type="date" value="<?php echo $r['date'] ?>" style="color:green;"></td>
                <td><input type="number" value="<?php echo $r['expense']?>" style="color:green;"></td>
                <td><input type="text" value="<?php echo $r['adminemail']?>" style="color:green;"></td>
                <td><input type="text" value="<?php echo $v?>" name="Credit"  style="color:green;"></td> 
                <?php
                }
             else{
                 ?>
                 <td><input type="date" value="<?php echo $r['date'] ?>" style="color:red;"></td>
                <td><input type="number" value="<?php echo $r['expense']?>" style="color:red;"></td>
                <td><input type="text" value="<?php echo $r['adminemail']?>" style="color:red;"></td>
                <td><input type="text" value="<?php echo $v?>" name="Debit"  style="color:red;"></td> 
                <?php
                  }
            ?>
            </tr>
               <?php
                    }

                }
            ?>
        </table>
             <br>
             <input type="button" value="Print this page" onclick="printPage()" />
        </center> 
        </div>
      </form>
        
    </body>
</html>
<?php

    if(isset($_POST['logout'])){

        $_SESSION['Login']=false;
        header('location:ChildHome.php');
    }
?>