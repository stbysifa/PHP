<ul><li><a href="ChildHome.php">Home</a></li>
	<li><a href="ChildExpense.php">Expense</a></li>
    <li><a href="ChildDisplay.php">Display</a></li>
    <li><a href="Transaction.php">Transaction</a></li>
    <li style="float: right;" class="logout"><a onclick="return confirm('Are you sure to logout')" href="Logout.php">Logout</a></li>
  </ul>