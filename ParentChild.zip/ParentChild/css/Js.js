function CheckLogin(){
    var x=document.getElementById("uname").value;
    var y=document.getElementById("pass").value;
    if(x=="sifa" && y=="123456"){   
        PrintLogin();
        alert("Valid username and password ,Login successful");
         return true;
    }
    else{
        alert("Invalid username and password");
        return false;  
    }
}

function PrintLogin(){
    //alert("sa");
    var a=document.getElementById("uname").value; 
    var b=document.getElementById('welcome').innerHTML;
    document.getElementById('welcome').innerHTML=b + " "+a;
}